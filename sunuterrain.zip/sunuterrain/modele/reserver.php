<?php

$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, 'sunuterrain');

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// declaration
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$telephone = $_POST['telephone'];
$email = $_POST['email'];
$terrain = $_POST['terrain'];
$moment = $_POST['moment'];
$horaire = $_POST['horaire'];

if (empty($nom) || empty($prenom) || empty($telephone) || empty($email) || empty($moment) || empty($horaire)) {
    echo "tout les champs sont obligatoires";
}
else {
    $sql = "INSERT INTO location (id,nom_user, prenom_user,tel_user,email, heure, moment) VALUES (null,'$nom','$prenom','$telephone','$email','$horaire','$moment')";
    if ($conn->query($sql) === TRUE) {
        $to = $email;
        $subject = "Confirmation";
        $txt = "Hello world!";
        mail($to,$subject,$txt);
        echo "Resrevation effectuée avec succés tu vas recevoir un mail de confirmtion";
        
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
}  
