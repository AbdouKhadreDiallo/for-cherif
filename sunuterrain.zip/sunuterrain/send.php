<?php
print phpinfo();  
// $to = "abdoudiallo405@gmail.com";
// $subject = "Confirmation";
// $txt = "Hello world!";
// $send = mail($to,$subject,$txt);
// var_dump(mail($to,$subject,$txt));
// if ($send) {
//     echo "sended";
// }
// else {
//     echo "error";
// }