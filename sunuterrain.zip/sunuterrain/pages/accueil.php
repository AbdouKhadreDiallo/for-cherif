<!-- <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            
            <div class="carousel-item active">
            <img class="d-block w-100" src="http://via.placeholder.com/325x125" alt="First slide">
                <div class="carousel-caption d-none d-md-block">
                    <h5>First</h5>
                    <p>First test</p>
                </div>
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="http://via.placeholder.com/325x125" alt="First slide">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Second</h5>
                    <p>Second Test</p>
                </div>
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="http://via.placeholder.com/325x125" alt="First slide">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Third</h5>
                    <p>Third Test</p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
</div>
<div class="container">
    <div class="row mt-3">
        <div class="col-lg-4">
            <img class="thumbnail" src="https://cdn-s-www.ledauphine.com/images/0F887D08-4560-450A-B02C-476F3AD85E5E/NW_raw/photo-d-illustration-paul-ellis-afp-1594485541.jpg" alt="" srcset="">
            
        </div>
        <div class="col-lg-4">
            <img class="thumbnail" src="https://www.leparisien.fr/resizer/yx-d6t7muZRnqaCaGaIaYh41yO0=/932x582/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/QNKKWFCKPXRAUSRJGBARFGANMI.jpg" alt="" srcset="">
            
        </div>
        
        <div class="col-lg-4">
            <img class="thumbnail" src="https://images.omerlocdn.com/resize?url=https%3A%2F%2Fgcm.omerlocdn.com%2Fproduction%2Fglobal%2Ffiles%2Fimage%2F3162dadb-efbc-4fb7-983b-e4b3a88068f1.png&stripmeta=true&width=1024&type=jpeg" alt="" srcset="">
            
        </div>
    </div>
</div> -->
<div class="container mt-5">
    <h3 class="text-center">Sunu terrain - location de terrain de foot en ligne</h3>
    <hr>
</div>

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-8 stade-image"></div>
        <div class="col-lg-3 stade-caracteristique ml-4 mt-5">
            <p>Sunuterain est une plateforme de location de terrain de foot</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse reiciendis eligendi ut deserunt aut id, perspiciatis fugit! Laudantium vitae deleniti sunt voluptates perspiciatis voluptatem ducimus commodi, facere tempora molestias officiis.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat cumque aliquid, libero molestias culpa illo laboriosam expedita vitae suscipit quo enim vel iste labore odio dolorum facilis mollitia! Repellat, sequi.</p>
        </div>
    </div>
    <hr>
</div>
 
<div class="container mt-5">
    <div class="partner"><h3>Nos partenaires</h3></div>
    <div class="row">
    <div class="col-lg-4" id="first-partner">
            <img class="thumbnail" src="https://cdn-s-www.ledauphine.com/images/0F887D08-4560-450A-B02C-476F3AD85E5E/NW_raw/photo-d-illustration-paul-ellis-afp-1594485541.jpg" alt="" srcset="">
            <div class="box-element product" id="first-patner-infos">
                <h6> <strong>Product</strong> </h6>
                <hr>
                <button class="btn btn-outline-secondary add-btn">Add to cart</button>
                <a href="#" class="btn btn-outline-success">view</a>
                <h4 style="display: inline-block;float: right;">$20</h4>
            </div>
        </div>
        <div class="col-lg-4" id="second-partner">
            <img class="thumbnail" src="https://www.leparisien.fr/resizer/yx-d6t7muZRnqaCaGaIaYh41yO0=/932x582/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/QNKKWFCKPXRAUSRJGBARFGANMI.jpg" alt="" srcset="">
            <div class="box-element product" id="second-patner-infos">
                <h6> <strong>Product</strong> </h6>
                <hr>
                <button class="btn btn-outline-secondary add-btn">Add to cart</button>
                <a href="#" class="btn btn-outline-success">view</a>
                <h4 style="display: inline-block;float: right;">$20</h4>
            </div>
        </div>
        
        <div class="col-lg-4" id="third-partner">
            <img class="thumbnail" src="https://images.omerlocdn.com/resize?url=https%3A%2F%2Fgcm.omerlocdn.com%2Fproduction%2Fglobal%2Ffiles%2Fimage%2F3162dadb-efbc-4fb7-983b-e4b3a88068f1.png&stripmeta=true&width=1024&type=jpeg" alt="" srcset="">
            <div class="box-element product" id="third-patner-infos">
                <h6> <strong>Product</strong> </h6>
                <hr>
                <button class="btn btn-outline-secondary add-btn">Add to cart</button>
                <a href="#" class="btn btn-outline-success">view</a>
                <h4 style="display: inline-block;float: right;">$20</h4>
            </div>
        </div>
    </div>
    <hr>
</div> 
<div class="container mt-5">
    <div class="contact row bg-dark">
        <div class="col-lg-4 formulaire mt-5">
            <form action="" method="post" class="mt-5 ml-4">
                <input type="text" name="" id="nomm" class="bg-dark" placeholder="NOM,PRENOM">
                <input type="email" name="" id="nomm" class="bg-dark mt-4" placeholder="EMAIL">
                <input type="text" name="" id="text-message" placeholder="MESSAGE" class="mt-4 bg-dark">
                <button type="submit" name="Reserver" id="envoyer" class="btn btn-primary mt-4">Envoyer</button>
            </form>
        </div>
        <div class="col-lg-4 numero-telephone mt-5">
            <div class="mt-5">
                <h3 class="ml-5 text-secondary">Contactez NOUS</h3> <br>
                <i class="fa fa-phone ml-5 mt-4 text-secondary"></i><span class="text-secondary ml-3">771234567 ou 781234567 </span> <br>
                <i class="fa fa-map-marker ml-5 mt-4 text-secondary"></i><span class="text-secondary ml-3">Darou thioub</span> <br>
                <i class="fas fa-envelope ml-5 mt-4 text-secondary"></i><span class="text-secondary ml-3">cherifsow92i@gmail.com</span>
            </div>
        </div>
        <div class="col-lg-4 reseaux-sociaux mt-5">
            <div class="mt-5">
                <h3 class="ml-4 text-secondary">Reseaux Sociaux</h3> <br>
                <div class="ab float:left"><a href="#"><i class="fab fa-facebook-f ml-4 mt-4 text-secondary"></i></a></div> 
            </div>
        </div>
    </div>
</div>
<?php
    include('./pages/footer.php');
?>
<script>
    function afficherInformations(infos, partenaire) {
        infos.hide();
        partenaire.hover(
        function() {
            infos.fadeIn("slow");
        }, function() {
            infos.fadeOut("slow");
        }
        );
    }
    first_infos = $("#first-patner-infos");
    second_infos = $("#second-patner-infos");
    third_infos = $("#third-patner-infos");
    first_partenaire = $("#first-partner");
    second_partenaire = $("#second-partner");
    third_partenaire = $("#third-partner");
    afficherInformations(first_infos, first_partenaire);
    afficherInformations(second_infos, second_partenaire);
    afficherInformations(third_infos, third_partenaire);
        
</script>
