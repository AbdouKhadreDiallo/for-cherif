<div class="container mt-4">
    <div class="row">
        <h4><span id="tiltle">Terrain de Foot</span></h4>
    </div>   
</div>
<div class="container border border-light mt-5 bg-info">
    <h2 class="text-center  font_2">
        <span style="letter-spacing:0.2em;" >
            <span class="center-this text-white">TARIFS ET DISPONIBILITÉS</span>
        </span>    
    </h2>
</div>

<div class="container mt-4">
<form method="post" id="form-connexion" action="Javascript:void(0);">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="Nom">Nom</label>
      <input type="text" class="form-control" id="Nom" name="nom">
    </div>
    <div class="form-group col-md-6">
      <label for="Prenom">Prenom</label>
      <input type="text" class="form-control" id="Prenom" name="prenom">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
        <label for="inputTelephone">telephone</label>
        <input type="text" class="form-control" id="inputTelephone" name="telephone">
    </div>
    <div class="form-group col-md-6">
        <label for="emailInput">Email</label>
        <input type="email" class="form-control" id="emailInput" name="email">
    </div>
</div>
  <div class="form-group">
    <label for="emailInput">Terrain</label>
    <select id="momentInput" class="form-control" name="terrain">
        <option value="" selected>Foire</option>
        <option>Fann</option>
    </select>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
        <label for="momentInput">Moment</label>
        <select id="momentInput" class="form-control" name="moment">
            <option selected>Jour</option>
            <option>Nuit</option>
        </select>
    </div>
    <div class="form-group col-md-6">
        <label for="heure">Horaire</label>
        <select id="heure" class="form-control" name="horaire">
            <option>19-20</option>
        </select>
    </div>
  </div>
  <button type="submit" name="Reserver" id="Reserver" class="btn btn-primary">Reserver</button>
</form>
</div>

<?php
    include('./pages/footer.php');
?>

<script src="./public/js/reserver.js"></script>