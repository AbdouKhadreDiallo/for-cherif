$(document).ready(function() {
    // alert('ready');
    $(document).on('click', '#Reserver', function(e) {
        // alert("ok");
        let myform = $('#form-connexion').serializeArray();
        console.log(myform);

        $.ajax({

            type: 'POST',
            url: 'http://localhost/sunuterrain/modele/reserver.php',
            data: myform,

            success: function(response) {
                alert(response);
                console.log(response);
            }
        })

    });
});